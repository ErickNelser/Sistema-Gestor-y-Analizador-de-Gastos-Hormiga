import { useState, useEffect } from 'react';

interface Gasto {
  id: number;
  fecha: string;
  concepto: string;
  monto: number;
  categoria: string;
  es_hormiga: boolean;
}

interface Resumen {
  total_gastado: string;
  total_hormiga: string;
  porcentaje_hormiga: string;
  proyeccion_anual: string;
  meta: { nombre: string; monto_objetivo: string };
  porcentaje_meta: string;
  resumen_categorias: { nombre: string; total: string }[];
}

export default function App() {
  const [texto, setTexto] = useState('');
  const [mensaje, setMensaje] = useState('');
  const [gastos, setGastos] = useState<Gasto[]>([]);
  const [resumen, setResumen] = useState<Resumen | null>(null);
  const [error, setError] = useState('');
  const [metaNombre, setMetaNombre] = useState('');
  const [metaMonto, setMetaMonto] = useState('');

  const fetchData = async () => {
    try {
      setError('');
      const [resGastos, resResumen] = await Promise.all([
        fetch('/api/gastos'),
        fetch('/api/resumen')
      ]);
      if (!resGastos.ok || !resResumen.ok) throw new Error();
      const dataGastos = await resGastos.json();
      const dataResumen = await resResumen.json();
      setGastos(dataGastos);
      setResumen(dataResumen);
      if (dataResumen.meta.monto_objetivo > 0) {
        setMetaNombre(dataResumen.meta.nombre);
        setMetaMonto(dataResumen.meta.monto_objetivo);
      }
      if (dataGastos.length === 0) setMensaje('Aún no registras gastos');
    } catch {
      setError('Servidor no disponible, intenta de nuevo en unos minutos');
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!texto.trim()) return;
    try {
      const res = await fetch('/api/gastos/texto', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ texto })
      });
      const data = await res.json();
      setMensaje(data.mensaje || data.error);
      setTexto('');
      fetchData();
    } catch {
      setError('Servidor no disponible, intenta de nuevo en unos minutos');
    }
  };

  const handleDelete = async (id: number) => {
    await fetch(`/api/gastos/${id}`, { method: 'DELETE' });
    fetchData();
  };

  const handleMeta = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch('/api/metas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre: metaNombre, monto_objetivo: metaMonto })
    });
    fetchData();
  };

  if (error) return <div className="error">{error}</div>;

  return (
    <div className="container">
      <h1>Analizador de Gastos Hormiga</h1>
      
      <form onSubmit={handleSubmit} className="input-group">
        <input 
          value={texto} 
          onChange={e => setTexto(e.target.value)} 
          placeholder="Ej: Ayer gasté 5 en pasaje, 16 en dos salteñas y hoy 10 en cafecito" 
          autoFocus
        />
        <button type="submit">Registrar</button>
      </form>
      {mensaje && <p className="mensaje">{mensaje}</p>}

      {resumen && (
        <div className="resumen-grid">
          <div className="card"><h3>Total Gastado</h3><p>Bs {resumen.total_gastado}</p></div>
          <div className="card"><h3>Total Hormiga</h3><p>Bs {resumen.total_hormiga}</p></div>
          <div className="card"><h3>% Hormiga</h3><p>{resumen.porcentaje_hormiga}%</p></div>
          <div className="card"><h3>Proyección Anual</h3><p>Bs {resumen.proyeccion_anual}</p></div>
        </div>
      )}

      {resumen && (
        <div className="meta-section">
          <h3>Meta de Ahorro: {resumen.meta.nombre || 'Sin nombre'}</h3>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${resumen.porcentaje_meta}%` }}>
              {resumen.porcentaje_meta}%
            </div>
          </div>
          <form onSubmit={handleMeta} className="meta-form">
            <input placeholder="Nombre meta" value={metaNombre} onChange={e => setMetaNombre(e.target.value)} required />
            <input type="number" placeholder="Monto objetivo" value={metaMonto} onChange={e => setMetaMonto(e.target.value)} required />
            <button type="submit">Actualizar Meta</button>
          </form>
        </div>
      )}

      {resumen && resumen.resumen_categorias.length > 0 && (
        <div className="categorias">
          <h3>Resumen por Categoría</h3>
          <ul>
            {resumen.resumen_categorias.map((c, i) => (
              <li key={i}>{c.nombre}: Bs {parseFloat(c.total).toFixed(2)}</li>
            ))}
          </ul>
        </div>
      )}

      <h3>Historial de Gastos</h3>
      {gastos.length === 0 ? (
        <p>Aún no registras gastos</p>
      ) : (
        <table>
          <thead>
            <tr><th>Fecha</th><th>Concepto</th><th>Categoría</th><th>Monto</th><th>Acción</th></tr>
          </thead>
          <tbody>
            {gastos.map(g => (
              <tr key={g.id} className={g.es_hormiga ? 'hormiga' : ''}>
                <td>{g.fecha}</td>
                <td>{g.concepto}</td>
                <td>{g.categoria}</td>
                <td>Bs {g.monto.toFixed(2)}</td>
                <td><button onClick={() => handleDelete(g.id)}>Borrar</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
