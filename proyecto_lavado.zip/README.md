# Sistema Gestor y Analizador de Gastos Hormiga

Proyecto universitario desarrollado con React (Frontend), Node + Express (Backend) y MySQL (Base de Datos).

## Arquitectura de Despliegue (3 VMs)
- **VM 1 (Windows 11, 192.168.56.10)**: Frontend compilado servido por Nginx. Configurar proxy en Nginx: `location /api/ { proxy_pass http://192.168.56.20:3000/; }`
- **VM 2 (Ubuntu, 192.168.56.20)**: Backend Node.js corriendo en puerto 3000.
- **VM 3 (Ubuntu, 192.168.56.30)**: Base de datos MySQL en puerto 3306.

## Instrucciones de Ejecución

### 1. Base de Datos (VM 3)
1. Instalar MySQL.
2. Ejecutar el script: `mysql -u root -p < database/gastos_hormiga.sql`

### 2. Backend (VM 2)
1. Instalar dependencias: `npm install`
2. Configurar `.env` con las credenciales de la VM 3.
3. Iniciar servidor: `npm run dev`

### 3. Frontend (VM 1)
1. Instalar dependencias: `npm install`
2. Compilar para producción: `npm run build`
3. Servir la carpeta `dist` resultante con Nginx.
4. Para desarrollo local: `npm run dev`

## Reglas de Negocio
- Separa gastos por coma, " y ", " luego ", " después ".
- Detecta "hoy" y "ayer", heredando la fecha a los siguientes gastos hasta cambiar.
- Identifica el primer número como monto.
- Clasifica por palabras clave (acepta plurales). Si no coincide, es "Otros".
- Gasto hormiga: categoría marcada como hormiga Y monto <= 20 Bs.
- Proyección anual: (Total hormiga / días desde primer gasto, mín 1) * 365.
